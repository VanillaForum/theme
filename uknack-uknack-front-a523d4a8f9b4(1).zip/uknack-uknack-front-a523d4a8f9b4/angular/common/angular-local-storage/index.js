require('./src/angular-local-storage.js');
module.exports = 'LocalStorageModule';
