require('./app/angular.audio.js');

module.exports = 'ngAudio';
