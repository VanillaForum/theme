0.2.0 / 2014-07-07 
==================

 * Renamed module to just `file-model` (Fixes #2)
 * basic test file
