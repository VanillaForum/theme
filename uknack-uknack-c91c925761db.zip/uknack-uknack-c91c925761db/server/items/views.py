import django_filters
from django.db.models import Q, F
from django.template.loader import get_template
from django.core.mail import EmailMultiAlternatives
from rest_framework import viewsets, status
from rest_framework.permissions import SAFE_METHODS, IsAuthenticated
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes

from .models import Item, Category
from notification.models import Notification
from . import serializers
from knacks.views import save_photos, ReadOnlyOrIsAdminUser, ConnectionsFilter
from server.settings import SUPPORT_EMAIL


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = serializers.CategorySerializer
    paginate_by = 100
    permission_classes = (ReadOnlyOrIsAdminUser,)


class CustomFilterList(django_filters.Filter):
    def filter(self, qs, value):
        if value not in (None, ''):
            values = [v for v in value.split(',')]
            return qs.filter(**{'%s__%s' % (self.name, self.lookup_type): values})
        return qs


class ItemFilter(django_filters.FilterSet):
    user_id = django_filters.NumberFilter(name="owner__id", lookup_type='exact')
    min_age = django_filters.NumberFilter(name="owner__age", lookup_type='gte')
    max_age = django_filters.NumberFilter(name="owner__age", lookup_type='lte')
    min_price = django_filters.NumberFilter(name="price", lookup_type='gte')
    max_price = django_filters.NumberFilter(name="price", lookup_type='lte')
    gender = django_filters.CharFilter(name="owner__gender", lookup_type='exact')
    college = django_filters.CharFilter(name="owner__college", lookup_type='exact')
    categories = CustomFilterList(name="category", lookup_type='in')
    connections_only = ConnectionsFilter(name="owner__connections", lookup_type='in')

    class Meta:
        model = Item
        fields = ['id', 'user_id', 'type', 'min_age', 'max_age', 'min_price', 'max_price', 'gender', 'categories',
                  'connections_only']

    def __init__(self, data=None, queryset=None, prefix=None, strict=None):
        data = data.copy()
        if hasattr(data, 'college') and data['college'] == '':
            data.pop('college', None)
        if hasattr(data, 'gender') and data['gender'] == '':
            data.pop('gender', None)
        super(ItemFilter, self).__init__(data, queryset, prefix, strict)


class ItemViewSet(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = serializers.ItemSerializer
    PAGINATE_BY_PARAM = 'page_size'
    filter_class = ItemFilter

    parser_classes = (MultiPartParser, FormParser)

    def create(self, request, *args, **kwargs):
        data = request.data

        save_photos(data)

        if data['willing_to_travel'] == 'true':
            data['willing_to_travel'] = True
        else:
            data['willing_to_travel'] = False

        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()

        data = request.data

        save_photos(data, instance)

        if data['willing_to_travel'] == 'true':
            data['willing_to_travel'] = True
        else:
            data['willing_to_travel'] = False

        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        return Response(serializer.data)

    def retrieve(self, request, *args, **kwargs):
        # Override the method to count views
        instance = self.get_object()

        # This will hit db only once and will not trigger signals -> will not update modified_at field
        Item.objects.filter(pk=instance.pk).update(views=F('views') + 1)
        # Add one to instance views to display the correct value. Do not save the instance!
        instance.views += 1

        serializer = self.get_serializer(instance)
        return Response(serializer.data)

    def check_object_permissions(self, request, obj):
        # Check if a user is an owner of the item if a request is not safe
        if request.method not in SAFE_METHODS and request.user != obj.owner:
            self.permission_denied(request)

        return super(ItemViewSet, self).check_object_permissions(request, obj)

    def get_queryset(self):
        sort_by = self.request.GET.get('sort_by', None)
        search_text = self.request.GET.get('search_text', None)
        queryset = super(ItemViewSet, self).get_queryset()

        if search_text:
            queryset = queryset.filter(Q(owner__first_name__icontains=search_text) |
                                       Q(owner__last_name__icontains=search_text) |
                                       Q(name__icontains=search_text) |
                                       Q(description__icontains=search_text))

        if sort_by:
            queryset = queryset.order_by('-modified_at')
        return queryset


@api_view(['POST'])
@permission_classes((IsAuthenticated,))
def buy_email(request):
    subject = 'Buy Item Request From Uknack'
    plaintext = get_template('buy_notification.txt')
    htmly = get_template('buy_notification.html')

    item = Item.objects.get(pk = request.data['item_id'])
    owner = item.owner
    email = owner.email
    name = owner.first_name + ' ' + owner.last_name
    client_name = request.user.first_name + ' ' + request.user.last_name
    context = ({'name': name, 'client': client_name})

    text_content = plaintext.render(context)
    html_content = htmly.render(context)

    msg = EmailMultiAlternatives(subject, text_content, SUPPORT_EMAIL, [email])
    msg.attach_alternative(html_content, "text/html")
    rst = msg.send()

    # put notification
    if rst == 1:
        buyer = request.user
        item_data = serializers.ItemSerializer(item).data
        Notification.objects.create(
            user=owner, 
            sender=buyer, 
            type=Notification.TYPE_BUY_REQUEST,
            data={
                'name': item_data['name'],
                'description': item_data['description'],
                'price': item_data['price'],
                'rating': item_data['rating'],
                'photos': item_data['photos'],
                'category': Category.objects.get(pk=item_data['category']).name,
            },
        )
        return Response({'result': rst}, status=status.HTTP_201_CREATED)
    else:
        return Response({'result': rst}, status=status.HTTP_400_BAD_REQUEST)
